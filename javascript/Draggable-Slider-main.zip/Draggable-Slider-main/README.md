# Draggable-Slider
Creating a draggable slider with vanilla JavaScript

### Link:
https://designsbyharp.github.io/Draggable-Slider/
